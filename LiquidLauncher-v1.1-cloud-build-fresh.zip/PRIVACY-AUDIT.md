# LiquidLauncher privacy audit

Expected app permissions: none.

Source:
- No Android uses-permission entries.
- No INTERNET permission.
- No network APIs.
- No advertising SDK.
- No analytics SDK.
- No account/cloud system.
- No contacts, location, camera or microphone permission.
- Folder data is stored locally with SharedPreferences.

Build:
- The workflow checks the final APK permission table using aapt.
- The workflow fails if android.permission.INTERNET is present.
- The cloud build runner itself needs network access to download build tools.

This audit applies to this supplied source/build configuration. A modified fork
or different build can contain different code.
