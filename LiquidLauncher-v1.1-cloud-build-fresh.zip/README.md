# LiquidLauncher 1.1

Privacy-first, lightweight Android launcher for Android 8.0+.

## Liquid Glass clock

The home screen now has a dedicated iOS-inspired Liquid Glass clock card:
- Large single clock
- 12/24-hour system preference
- Date below the time
- Translucent layered glass
- Bright glass highlight
- Soft depth/shadow
- Blue/violet liquid gradient

Android 8.1 does not provide the modern system blur API, so this uses lightweight
layered translucent shapes instead of expensive real-time blur. This is intentional
for a 2 GB RAM phone.

## Features

- Home launcher activity
- Installed-app grid
- App search
- Working local folders
- Long-press apps to add to folders
- Tap folder apps to launch
- Long-press folder apps to remove
- No ads
- No analytics SDK
- No accounts/cloud
- No contacts/location/camera/microphone permissions

## Privacy

AndroidManifest.xml contains no uses-permission entries.

The GitHub Actions workflow checks the actual APK with aapt and fails if
android.permission.INTERNET is present.

The GitHub build machine still uses network access to obtain build tools. That
does not give the resulting APK INTERNET permission.

Keep the repository private for source privacy.

## Build

The workflow uses Java 17, Gradle 8.2 and Android SDK 34.

APK:
app/build/outputs/apk/debug/app-debug.apk
