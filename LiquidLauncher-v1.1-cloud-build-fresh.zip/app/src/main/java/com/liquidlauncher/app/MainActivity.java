package com.liquidlauncher.app;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.*;
import android.text.format.DateFormat;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final String KEY_FOLDERS = "folders";
    private final ArrayList<AppItem> allApps = new ArrayList<>();
    private final ArrayList<AppItem> shownApps = new ArrayList<>();
    private final ArrayList<Folder> folders = new ArrayList<>();
    private TextView clock, date;
    private GridView appsGrid;
    private EditText search;
    private AppAdapter adapter;
    private Timer timer;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        setContentView(R.layout.activity_main);

        clock = findViewById(R.id.clock);
        date = findViewById(R.id.date);
        appsGrid = findViewById(R.id.apps);
        search = findViewById(R.id.search);

        loadFolders();
        loadApps();

        adapter = new AppAdapter(this, shownApps);
        appsGrid.setAdapter(adapter);
        appsGrid.setOnItemClickListener((p,v,pos,id) -> launch(shownApps.get(pos)));
        appsGrid.setOnItemLongClickListener((p,v,pos,id) -> {
            addToFolder(shownApps.get(pos));
            return true;
        });

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int a,int c,int d) {}
            public void onTextChanged(CharSequence s,int a,int b,int c) { filter(s.toString()); }
            public void afterTextChanged(Editable e) {}
        });

        findViewById(R.id.folderButton).setOnClickListener(v -> folderManager());
        findViewById(R.id.settingsButton).setOnClickListener(v -> settings());

        updateClock();
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() { runOnUiThread(() -> updateClock()); }
        }, 30000, 30000);
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);

        for (ResolveInfo r : list) {
            if (r.activityInfo == null) continue;
            if (getPackageName().equals(r.activityInfo.packageName)) continue;
            allApps.add(new AppItem(
                r.loadLabel(pm).toString(),
                r.activityInfo.packageName,
                r.activityInfo.name,
                r.loadIcon(pm)
            ));
        }

        Collections.sort(allApps, (a,b) -> a.name.compareToIgnoreCase(b.name));
        shownApps.addAll(allApps);
    }

    private void filter(String q) {
        shownApps.clear();
        q = q.toLowerCase(Locale.getDefault()).trim();
        for (AppItem a : allApps)
            if (q.isEmpty() || a.name.toLowerCase(Locale.getDefault()).contains(q))
                shownApps.add(a);
        adapter.notifyDataSetChanged();
    }

    private void launch(AppItem a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setClassName(a.packageName, a.activityName);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open app", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateClock() {
        boolean is24 = DateFormat.is24HourFormat(this);
        String timePattern = is24 ? "HH:mm" : "h:mm";
        String datePattern = "EEEE, MMMM d";
        clock.setText(new SimpleDateFormat(timePattern, Locale.getDefault()).format(new Date()));
        date.setText(new SimpleDateFormat(datePattern, Locale.getDefault()).format(new Date()));
    }

    private void loadFolders() {
        try {
            JSONArray a = new JSONArray(getPreferences(0).getString(KEY_FOLDERS, "[]"));
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                Folder f=new Folder(o.optString("name","Folder"));
                JSONArray apps=o.optJSONArray("apps");
                if(apps!=null) for(int j=0;j<apps.length();j++) f.packages.add(apps.optString(j));
                folders.add(f);
            }
        } catch(Exception ignored) {}
    }

    private void saveFolders() {
        JSONArray a=new JSONArray();
        try {
            for(Folder f:folders) {
                JSONObject o=new JSONObject();
                o.put("name",f.name);
                JSONArray apps=new JSONArray();
                for(String p:f.packages) apps.put(p);
                o.put("apps",apps);
                a.put(o);
            }
        } catch(Exception ignored) {}
        getPreferences(0).edit().putString(KEY_FOLDERS,a.toString()).apply();
    }

    private void createFolder() {
        final EditText e=new EditText(this);
        e.setSingleLine(true);
        e.setHint("Folder name");
        new AlertDialog.Builder(this).setTitle("Create folder").setView(e)
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Create",(d,w)->{
                String n=e.getText().toString().trim();
                if(!n.isEmpty()){folders.add(new Folder(n));saveFolders();}
            }).show();
    }

    private void folderManager() {
        if(folders.isEmpty()){
            new AlertDialog.Builder(this).setTitle("Folders")
                .setMessage("No folders yet. Create one, then long-press an app to add it.")
                .setNegativeButton("Close",null)
                .setPositiveButton("Create folder",(d,w)->createFolder()).show();
            return;
        }

        String[] names=new String[folders.size()+1];
        for(int i=0;i<folders.size();i++)
            names[i]=folders.get(i).name+" ("+folders.get(i).packages.size()+")";
        names[folders.size()]="Create new folder";

        new AlertDialog.Builder(this).setTitle("Folders").setItems(names,(d,w)->{
            if(w==folders.size()) createFolder(); else showFolder(folders.get(w));
        }).setNegativeButton("Close",null).show();
    }

    private void addToFolder(AppItem app) {
        if(folders.isEmpty()){createFolder();return;}

        String[] names=new String[folders.size()+1];
        for(int i=0;i<folders.size();i++) names[i]=folders.get(i).name;
        names[folders.size()]="Create new folder";

        new AlertDialog.Builder(this).setTitle("Add "+app.name)
            .setItems(names,(d,w)->{
                if(w==folders.size()) createFolder();
                else {folders.get(w).packages.add(app.packageName);saveFolders();}
            }).setNegativeButton("Cancel",null).show();
    }

    private void showFolder(Folder f) {
        ArrayList<AppItem> items=new ArrayList<>();
        for(String p:f.packages)
            for(AppItem a:allApps)
                if(p.equals(a.packageName)){items.add(a);break;}

        if(items.isEmpty()){
            new AlertDialog.Builder(this).setTitle(f.name).setMessage("Folder is empty.")
                .setNegativeButton("Close",null)
                .setPositiveButton("Delete folder",(d,w)->{folders.remove(f);saveFolders();}).show();
            return;
        }

        ListView list=new ListView(this);
        list.setDivider(null);
        list.setAdapter(new FolderAdapter(this,items));

        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(f.name).setView(list)
            .setNegativeButton("Close",null)
            .setPositiveButton("Delete folder",(d,w)->{folders.remove(f);saveFolders();}).create();

        list.setOnItemClickListener((p,v,pos,id)->launch(items.get(pos)));
        list.setOnItemLongClickListener((p,v,pos,id)->{
            f.packages.remove(items.get(pos).packageName);
            saveFolders();
            dialog.dismiss();
            return true;
        });
        dialog.show();
    }

    private void settings() {
        new AlertDialog.Builder(this).setTitle("LiquidLauncher")
            .setMessage("Privacy-first build\n\n"
                + "No INTERNET permission\n"
                + "No ads\n"
                + "No analytics SDK\n"
                + "No accounts or cloud\n"
                + "No contacts, location, camera or microphone permissions\n"
                + "Folders are stored locally.\n\n"
                + "Liquid Glass clock: layered translucent glass, highlight and glow.\n"
                + "Version 1.1")
            .setPositiveButton("OK",null).show();
    }

    @Override protected void onDestroy() {
        if(timer!=null) timer.cancel();
        super.onDestroy();
    }

    static class AppItem {
        String name,packageName,activityName; Drawable icon;
        AppItem(String n,String p,String a,Drawable i){name=n;packageName=p;activityName=a;icon=i;}
    }

    static class Folder {
        String name; Set<String> packages=new LinkedHashSet<>();
        Folder(String n){name=n;}
    }

    static class AppAdapter extends BaseAdapter {
        Context c; ArrayList<AppItem>d;
        AppAdapter(Context c,ArrayList<AppItem>d){this.c=c;this.d=d;}
        public int getCount(){return d.size();}
        public Object getItem(int p){return d.get(p);}
        public long getItemId(int p){return p;}
        public View getView(int p,View v,ViewGroup parent){
            LinearLayout box=new LinearLayout(c);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);

            ImageView icon=new ImageView(c);
            icon.setImageDrawable(d.get(p).icon);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            box.addView(icon,new LinearLayout.LayoutParams(dp(54),dp(54)));

            TextView name=new TextView(c);
            name.setText(d.get(p).name);
            name.setTextColor(Color.WHITE);
            name.setTextSize(11);
            name.setGravity(Gravity.CENTER);
            name.setSingleLine(true);
            box.addView(name,new LinearLayout.LayoutParams(-1,dp(28)));
            return box;
        }
        int dp(int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
    }

    static class FolderAdapter extends BaseAdapter {
        Context c; ArrayList<AppItem>d;
        FolderAdapter(Context c,ArrayList<AppItem>d){this.c=c;this.d=d;}
        public int getCount(){return d.size();}
        public Object getItem(int p){return d.get(p);}
        public long getItemId(int p){return p;}
        public View getView(int p,View v,ViewGroup parent){
            LinearLayout row=new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12),dp(8),dp(12),dp(8));

            ImageView icon=new ImageView(c);
            icon.setImageDrawable(d.get(p).icon);
            row.addView(icon,new LinearLayout.LayoutParams(dp(44),dp(44)));

            TextView name=new TextView(c);
            name.setText(d.get(p).name);
            name.setTextColor(Color.WHITE);
            name.setTextSize(16);
            name.setPadding(dp(16),0,0,0);
            row.addView(name,new LinearLayout.LayoutParams(0,dp(56),1));
            return row;
        }
        int dp(int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
    }
}
